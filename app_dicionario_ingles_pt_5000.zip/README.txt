App Dicionário Inglês → Português

Arquivos:
- index.html
- dicionario.json

Entradas no JSON: 5000

Como subir no GitHub pelo celular:
1. Abra seu repositório.
2. Substitua o index.html pelo arquivo deste pacote.
3. Crie/suba o arquivo dicionario.json na raiz do repositório.
4. Aguarde o GitHub Pages atualizar.
5. Abra seu link com ?v=5000 no final para evitar cache.
